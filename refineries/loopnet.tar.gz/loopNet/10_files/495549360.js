/* AG-develop 12.7.1-649 (2012-09-20 11:43:57 PDT) */
rsinetsegs = ['K08784_10001','K08784_10283','K08784_10307','K08784_10437'];
if(typeof(DM_onSegsAvailable)=="function"){DM_onSegsAvailable(['K08784_10001','K08784_10283','K08784_10307','K08784_10437'],'k08784');}